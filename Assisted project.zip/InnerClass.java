package Project;

 class innerClass1 {

		 private String msg="hello world"; 
		 
		 class Inner{  
		  void hello(){
			  System.out.println(msg+", this is my first program");}  
		 }  


		public static void main(String[] args) {

			innerClass1 obj=new innerClass1();
			innerClass1.Inner in=obj.new Inner();  
			in.hello();  
		}
	}


 class innerClass2 {

	private String msg="java";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	  }  
	  
	  Inner l=new Inner();  
	  l.msg();  
	 }  

	 
	public static void main(String[] args) {
		innerClass2  I2=new innerClass2 ();  
		I2.display();  
		}
	}
	//anonymous inner class
	abstract class AnonymousInnerClass {
		   public abstract void display();
		}


		public class InnerClass{

		public static void main(String[] args) {
		AnonymousInnerClass i = new AnonymousInnerClass() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      i.display();
		   }
		}



