package Project;
import java.util.Scanner;
class CustomerID{
	int a[]= {15,8,78,22,21};//initializing array
	int b[];
	int n;
	int c[][]= {{1,2,3},{4,5,6}};
	void displaySingle() {
		System.out.println("the 1Darray elements are");
	for( int i:a) {
		i=i++;
		System.out.println(i);
}}
	void displayFromUser(){
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the array size");
	n=sc.nextInt();
	System.out.println("enter the array elements");
	for( int i=0;i<n;i++) {
		a[i]=sc.nextInt();
	}
	System.out.println("the 1Darray elements are");
		for( int i:a) {
			i=i++;
			System.out.println(i);
	}
	}
	void displayMultiple() {
		System.out.println("the 2Darray elements are");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
		        System.out.println(c[i][j]+" ");	
		}
	}
}
public class Arrays {
	public static void main(String[] args) {
		CustomerID C=new CustomerID();
		C.displaySingle();
		C.displayFromUser();
		C.displayMultiple();
	}

}
