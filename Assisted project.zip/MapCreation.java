package Project;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map.Entry;
import java.util.TreeMap;

class map{
	void HM() {
		HashMap<Integer,String> hm=new HashMap<Integer,String>();      
	      hm.put(1,"Moni");    
	      hm.put(2,"Mathi");    
	      hm.put(3,"kishore");   
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Entry<Integer, String> E:hm.entrySet()){    
	       System.out.println(E.getKey()+" "+E.getValue());    
	      }
	      

	}
	void HT() {
		Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
	      
	      ht.put(4,"yazhini");  
	      ht.put(5,"ranjani");  
	      ht.put(6,"nivetha");  
	      ht.put(7,"shiva");  

	      System.out.println("\nThe elements of HashTable are ");  
	      for(Entry<Integer, String> n:ht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    

	      }
	}
	      void TM() {
	          TreeMap<Integer,String> tm=new TreeMap<Integer,String>();    
		      tm.put(8,"loki");    
		      tm.put(9,"sivaguru");    
		      tm.put(10,"naija");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Entry<Integer, String> t:tm.entrySet()){    
		       System.out.println(t.getKey()+" "+t.getValue());    

	      }
}}

public class MapCreation {
public static void main(String[] args) {
	map m=new map();
	m.HM();
	m.HT();
	m.TM();
	
}
}
