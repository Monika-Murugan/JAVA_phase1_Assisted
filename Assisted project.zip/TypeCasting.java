package Project;


public class TypeCasting {

		public static void main(String[] args) {
			
			//implicit conversion
			System.out.println("Implicit Type Casting");
			char a='T';
			System.out.println(" a=: "+a);
			
			int b=a;
			System.out.println(" b=: "+b);
			
			float c=a;
			System.out.println(" c=: "+c);
			
			long d=a;
			System.out.println(" d=: "+d);
			
			double e=a;
			System.out.println(" e=: "+e);
			
					
			System.out.println("\n");
			//explicit conversion
			System.out.println("Explicit Type Casting");
			
			int f=15;
			float g=(float)f;
			System.out.println(" f=: "+f);
			System.out.println(" g=: "+g);
			
		}
	}
