package Project;
class Access{
	int a,b;//default
	public int c,d;//public
	private int e,f;//private
	protected int g,h;//protected
	
     int add(int a,int b)
	{
		return a+b;
	}
	int sub(int c,int d) { 
		return c-d;
			}
	int dev(int g, int h) {
		return g*h;
		
	}
	public int getE() {
		return e;
	}
	public void setE(int e) {
		this.e = e;
	}
	public int getF() {
		return f;
	}
	public void setF(int f) {
		this.f = f;
	}
	public int mul(int e, int f)
	{
		return e*f;
	}

}

public class AccessModifier {
	public static void main(String[] args) {
		
     Access A= new Access();
     System.out.println("the addition of defualt variable=" + A.add(10, 5));
     System.out.println("the subtraction of public variable="+A.sub(20, 10));
     System.out.println("the devision of protected variable="+A.dev(16, 4));
     A.setE(5);
     A.setF(10);
     System.out.println("the multiplication of private variable="+A.mul(A.getE(),A.getF() ));
	}
     
}
