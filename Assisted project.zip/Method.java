package Project;
class Student{
	String name;//attributes
	int ID;
	int age;
	int mark=90;
	void display(String name,int ID,int age)//declaring a method
	{
		System.out.println("name= "+name+"\n"+"ID= "+ID+"\n"+"age= "+age);
	}
	void display(String name,int ID,int age,int mark) {//Method overriding
		System.out.println("name= "+name+"\n"+"ID= "+ID+"\n"+"age= "+age+"\n"+"Mark= "+mark);
	
	}
	void add(int mark) {//call by value
		mark=mark+5;
	}
		
}

public class Method {
	public static void main(String[] args) {
		Student S=new Student();//declaring objects
		S.display("Moni",1,20);//calling an method and Passing an arguments
		S.display("Yazhini", 4, 20, 95);
		S.display("Mathi",2,20);
		S.display("Nivetha",2,20);
		System.out.println("Before adding additional mark to mark= "+S.mark);
		S.add(S.mark);
		System.out.println("After adding additional mark to mark= "+S.mark);
	}

}
