package Project;
	class StringS{
		void strinOnly() {
			System.out.println("Operations of string");
			String s1="Hello";
			String s2="World";
			//length
			System.out.println("the string length is "+s1.length());
			//***to find a character at a specific location
			System.out.println("the character at a location is "+s1.charAt(2));
			//find the location from a character
			System.out.println("location of a character "+s1.indexOf('o'));
			//find the location from a character in reverse
			System.out.println("location of a character in reverse "+s1.lastIndexOf('l'));
			//convert the string to upper case and lower case
			System.out.println("convert lower to upper "+s1.toUpperCase());
			//substring
			System.out.println("substring model 1 "+s1.substring(2));
			System.out.println("substring model 2 "+s2.substring(2,5));
			//equals()
			System.out.println("equals " +s1.equals(s2));
			//split
			System.out.println("split example");
			String s3="abcd_edf_ijkl";
			String ss[]=s3.split("_");
			for(String l:ss) {
				System.out.println(l);
			}
			//compareTo
			 String s4="abcdefd";
			 String s5="efd" ;
			 System.out.println("string compare "+s4.compareTo(s5));
			//conversions
				int a1=1;
				String s6=a1+"";
				String s7=String.valueOf(a1);
				System.out.println("Type of the conerted int to string");
				System.out.println(s6.getClass());
				String s51=Integer.toString(a1);
				System.out.println(s7.getClass());
				System.out.println("\n");
		}
		void StrBuf()
		{
			System.out.println("Operations of StringBuffer");
			 StringBuffer s=new StringBuffer("Hello");
		     //append
		     s.append(" world");
		      System.out.println(s);
		     //insert
		      s.insert(5, " beautiful");
		      System.out.println(s); 
		      //replace
		      s.replace(0, 5, "Hi");
		      System.out.println(s);
		     //string to reverse
		      StringBuffer sb=new StringBuffer(s);
		      sb.reverse();
		      System.out.println(sb);
		      System.out.println("\n");
		}
		void strBul() {
			System.out.println("Operations of StringBuilder");
			StringBuilder sb1=new StringBuilder("Happy");
			sb1.append("Learning");
			System.out.println(sb1);

			System.out.println(sb1.delete(0, 1));

			System.out.println(sb1.insert(1, "Welcome"));

			System.out.println(sb1.reverse());
			 System.out.println("\n");		
		}
		void convertions() {
	        
	        // conversion from String object to StringBuffer 
			String str="learning";
	        StringBuffer sbr = new StringBuffer(str); 
	        sbr.reverse(); 
	        System.out.println("String to StringBuffer");
	        System.out.println(sbr); 
	          
	        // conversion from String object to StringBuilder 
	        StringBuilder sbl = new StringBuilder(str); 
	        sbl.append(" is fun"); 
	        System.out.println("String to StringBuilder");
	        System.out.println(sbl);              

		}
		    	
	}


	public class StringDemo {

		public static void main(String[] args) {
	StringS str=new StringS();
	str.strinOnly();
	str.StrBuf();
	str.strBul();
	str.convertions();		
	}

	}


