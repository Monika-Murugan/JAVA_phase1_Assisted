package Project;
import java.util.*;
class Collections{
	void arraylist() {
		System.out.println("ArrayList");
		ArrayList<String> name=new ArrayList<String>();   
	      name.add("Moni");//
	      name.add("Mathi");    	   
	      System.out.println(name); 
		
	}
	void vector() {
		 System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> v = new Vector();
	      v.addElement(5); 
	      v.addElement(3); 
	      System.out.println(v);
		
	}
	void LinkedList()
	{
		System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> mail=new LinkedList<String>();  
	      mail.add("abc@gmail.com");  
	      mail.add("def@gmail.com");  	      
	      Iterator<String> i=mail.iterator();  
	      while(i.hasNext()){  
	       System.out.println(i.next()); 
	}}
	 void HashSetCreation()
	      
	      {
	    	  System.out.println("\n");
		       System.out.println("HashSet");
		       HashSet<Integer> set1=new HashSet<Integer>();  
		       set1.add(1);  
		       set1.add(3);  
		       set1.add(2);
		       set1.add(4);
		       System.out.println(set1);
		       
	      }
	 void Linkedhashsetcreation()
	 {
		  System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(13);  
	       set2.add(12);
	       set2.add(14);	       
	       System.out.println(set2);
	 }
}

public class Collection {
	public static void main(String[] args) {
		 Collections c=new Collections();
	       c.arraylist();
	       c.LinkedList();
	       c.HashSetCreation();
	       c.Linkedhashsetcreation();
	       c.vector();

	   
	      	} 
	      
	}




