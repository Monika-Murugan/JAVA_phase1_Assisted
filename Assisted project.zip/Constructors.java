package Project;
//Default constructor
class constructor{
	constructor(){
		int a=10,b=15;
		System.out.println("A+B= "+(a+b));
	}
// Parameterized constructor
	constructor(int c, int d){
	System.out.println("C+D= "+(c+d));
	}
}
public class Constructors {
public static void main(String[] args) {
	constructor D=new constructor();
	constructor P=new constructor(20,30);
}
}
