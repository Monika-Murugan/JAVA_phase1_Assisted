package Project;
import java.util.regex.*;
public class RegularExpression {
	public static void main(String[] args) {
		
	String pattern = "Regular";
	String check = "Regular Expressions";
	Pattern p = Pattern.compile(pattern);
	Matcher m = p.matcher(check);
	
	while (m.find()) {
      	System.out.println("Pattern found from "
                + m.start() + " to "
                + (m.end() - 1)  );

}}}