package project2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
class Operation{
	Scanner sc=new Scanner(System.in);
	String path="C:\\Assessment\\";
	void Update() throws IOException {
		System.out.println("enter the filename");
		String filename1=sc.next();
		String finalpath=path+filename1;
		File f1=new File(finalpath);
		//create a new file
		boolean b=f1.createNewFile();
		if(b!=true) {
			System.out.println("file not created");
		}
		else {
			System.out.println("file created");
		}
	}
	void ReadAssisted() throws IOException   {
		System.out.println("enter the file name");
		String filename1=sc.nextLine();
		String finalpath1=path+filename1;
		FileInputStream fi=new FileInputStream(finalpath1);
		if(fi!=null) {
			System.out.println("file exists");
		}
		int i=0;
		//-1 is EOF
		while((i=fi.read())!=-1){
			System.out.print((char)i);
		}

		fi.close();
	}
	void WriteAssisted() throws IOException {
		System.out.println("enter the file name");
		String filename2=sc.nextLine();
		String finalpath2=path+filename2;
		FileOutputStream fo=new FileOutputStream(finalpath2,true);
		if(fo!=null) {
			System.out.println("file existed and opened in write mode");
		}
		System.out.println("enter the content to write on the file ");
		String fileinput=sc.nextLine();
		byte b[]=fileinput.getBytes();
		fo.write(b);
		System.out.println("write operation completed");
		fo.close();
		}
	void DeleteAssisted() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the filename");
		String filename2=sc.next();
		String finalpath1=path+filename2;
		File f=new File(finalpath1);
		//delete operation
		f.delete();
		System.out.println("file gets deleted");
	}
}

public class FilesAssisted {
	public static void main(String[] args) throws IOException {
		System.out.println("Choose which operation has to be done!!"+"\n"+"1. update"+"\n"+"2. read"+"\n"+"3. delete"+"\n"+"4. write");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		String path="C:\\Assessment\\";
		Operation O=new Operation();
			switch(choice)
			{
			case 1:
				O.Update();
				break;
			case 2:
				O.ReadAssisted();
				break;
			case 3:
				O.DeleteAssisted();
				break;
			case 4:
				O.WriteAssisted();
				break;
			}

}}
