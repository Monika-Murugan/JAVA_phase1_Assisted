package project2;


class N implements Runnable{
	public void run() {
		try {
			numOdd();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		numEven();
	}
	
	 void numOdd() throws InterruptedException {
		for(int i=1;i<9;i=i+2) {
			System.out.println(i);
			Thread.sleep(2000);
		}
	}
	
	 void numEven() {
		for(int i=2;i<9;i+=2) {
			System.out.println(i);
		}
	}
	
}

public class SleepEx {
	public static void main(String[] args) {
					//normal object
		N numi=new N();
		//thread obj must be made
		Thread t1=new Thread(numi);
		Thread t2=new Thread(numi);
		t1.start();
		t2.start();
	
	}

}



