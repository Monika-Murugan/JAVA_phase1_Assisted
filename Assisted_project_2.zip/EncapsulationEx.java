package project2;
class EmployeeGet {
	private int id;
	private String name;
	private int salary;
    private int bonus;
	String finalamount;
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getsalary() {
		return salary;
	}


	public void setsalary(int salary) {
		this.salary = salary;
	}
	public int getbonus() {
		return salary+bonus;
	}


	public void setbonus(int bonus) {
		this.bonus=bonus;
	}

     

	@Override
	public String toString() {
		return "College [id=" + id + ", name=" + name + ", salary=" + salary + ", Finalamount="+ getbonus()+"]";

}}








public class EncapsulationEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeGet Emp1=new EmployeeGet();
		EmployeeGet Emp2=new EmployeeGet();
		EmployeeGet Emp3=new EmployeeGet();
		Emp1.setId(1);
		Emp1.setName("Monika");
		Emp1.setsalary(45000);
		Emp1.setbonus(1000);
		Emp2.setId(2);
		Emp2.setName("Mathi");
		Emp2.setsalary(50000);
		Emp2.setbonus(500);
		Emp3.setId(3);
		Emp3.setName("Nivetha");
		Emp3.setsalary(46000);
		Emp3.setbonus(1000);
		System.out.println(Emp1+"\n"+Emp2+"\n"+Emp3);

	}

}

