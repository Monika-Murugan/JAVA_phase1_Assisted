package project2;

public class FinallyEx {
	public static void main(String[] args) {
		try {//try block
		
		System.out.println("hi users");
		}
		catch(Exception e) {
			System.out.println(e);
			
		}
		try {//nested try block
			try {
				int a=50/3;//exception obj is invoked
			}
			catch(Exception e) {
				System.out.println(e);	
			}
			int b[]= {2,3,4,5,6};
			b[2]=24;
		}
		finally{
			System.out.println("i am happy");	
		}
		System.out.println("welcome to phase 1");
	}

}

