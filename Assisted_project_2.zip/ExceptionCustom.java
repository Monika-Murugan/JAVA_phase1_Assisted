package project2;
 class AgeValidation {
	
	public void validAge(int age) throws InvalidAgeException {
		if(age>=18) {
			System.out.println("right to vote");
		}
		else {
			throw new InvalidAgeException("the age is not matching with the right of vote");
		}
	}

}
 class InvalidAgeException extends Exception {

 	public InvalidAgeException(String str) {
 		super(str);
 	}

 }

public class ExceptionCustom {
public static void main(String[] args) throws InvalidAgeException {
	AgeValidation valid=new AgeValidation();
	valid.validAge(12);
}
}


