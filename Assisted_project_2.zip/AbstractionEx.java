package project2;


abstract class Calculator{
	public abstract void sum(int a, int b);
	public abstract void sub(int a, int b);
}



class CalImp extends Calculator{

	@Override
	public void sum(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}

	@Override
	public void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
	}
	
}

public class AbstractionEx {
public static void main(String[] args) {
	CalImp imp=new CalImp();
	imp.sum(2, 3);
	imp.sub(7, 5);
}}

