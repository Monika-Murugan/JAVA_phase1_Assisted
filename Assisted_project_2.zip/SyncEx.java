package project2;


class Nu implements Runnable{
	public void run() {
		numOdd();
		numEven();
	}
	
	synchronized void numOdd() {
		for(int i=1;i<9;i=i+2) {
			System.out.println(i);
		}
	}
	
	synchronized void numEven() {
		for(int i=2;i<9;i+=2) {
			System.out.println(i);
		}
	}
	
}

public class SyncEx {
	public static void main(String[] args) {
					//normal object
		Nu numi=new Nu();
		//thread obj must be made
		Thread t1=new Thread(numi);
		Thread t2=new Thread(numi);
		t1.start();
		t2.start();
	
	}

}
