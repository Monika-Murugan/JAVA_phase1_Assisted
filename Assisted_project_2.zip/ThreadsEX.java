package project2;



class NumberIteration extends Thread{
		public void run() {
			for(int i=0;i<9;i++) {
				System.out.println(i);
			}
		}
		
	}

public class ThreadsEX  {
		public static void main(String[] args) {
						//thread object
			NumberIteration numi=new NumberIteration();
			numi.start();
		
		}

	}







