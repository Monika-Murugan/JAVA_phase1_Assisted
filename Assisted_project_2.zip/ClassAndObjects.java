package project2;

	class ClassAndObjects{
		//data
		int id=1;
		double salary=2000;
		String geneder="male";
		void display() {
	System.out.println(id +"  "+salary+"  "+geneder);		
			
		}
		
		public static void main(String[] args) {
			String name="ravi";
		ClassAndObjects demo=new ClassAndObjects();	
		System.out.println(demo);	
		System.out.println(demo.salary);
		demo.display();
		
		}

}
